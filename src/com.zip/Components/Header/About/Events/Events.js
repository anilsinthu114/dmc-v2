import React from "react";
import Typography from "@mui/material/Typography";
import "../About.css";

function Events() {
  return (
    <div className="allRightContent">
      <div className="allRightContentProfile">
        <div className="allRightContentHeading">DMC Events</div><hr></hr>

        <Typography>
       
        </Typography><br />
        
        
        <Typography>
        
        </Typography><br /><br />
      </div>
    </div>
  );
}

export default Events;
