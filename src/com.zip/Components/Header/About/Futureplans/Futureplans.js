import React from "react";
import Typography from "@mui/material/Typography";
import "../About.css";

function Futureplans() {
  return (
    <div className="allRightContent">
      <div className="allRightContentProfile">
        <div className="allRightContentHeading">DMC Future Plans</div><hr></hr>

        <Typography>
       
        </Typography><br />
        
        
        <Typography>
        
        </Typography><br /><br />
      </div>
    </div>
  );
}

export default Futureplans;
