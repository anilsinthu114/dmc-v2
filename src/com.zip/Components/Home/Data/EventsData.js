// EventsData.js
const events = [
    {
      sno: 1,
      name: "5 Day FDP on 'MOODLE Learning Management System'",
      date: "22-07-2020 to 26-07-2020",
    },
    {
      sno: 2,
      name: "A 15 day online FDP on 'Data Science and its Applications in STEM'",
      date: "07-09-2020 to 21-09-2020",
    },
    {
      sno: 3,
      name: "Workshop on 'Systems Office Administration and Fundamentals'",
      date: "16-09-2020 to 30-09-2020 (3PM to 5 PM)",
    },
  ];
  
  export default events;
  