import React from 'react';
import './Data.css';

function PCOI() {
  return (
    <div className="app-container">
      <div className="under-construction">
        <h1>Pharmacy Council of India Web Page is Under Construction</h1>
        <p>We are working on something great and will be back soon with valuable information!</p>
      </div>
    </div>
  );
}

export default PCOI;
