import React from 'react';
import './Data.css';

function FA() {
  return (
    <div className="app-container">
      <div className="under-construction">
        <h1>Faculty Awards Web Page is Under Construction</h1>
        <p>We are working on something great and will be back soon with valuable information!</p>
      </div>
    </div>
  );
}

export default FA;
